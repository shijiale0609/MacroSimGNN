#!/bin/bash
#$ -M jshi1@nd.edu
#$ -m abe
#$ -q long
#$ -pe smp 1

source ~/.bashrc
conda activate simgnn

# Define the dataset directories to process
datasets=("10_42" "10_53" "10_64" "10_75" "10_86")

# Loop through each dataset
for dataset in "${datasets[@]}"; do
    echo "Starting job for dataset: $dataset"
    
    # Check if dataset directory exists
    if [ ! -d "$dataset" ]; then
        echo "Warning: Directory $dataset does not exist, skipping..."
        continue
    fi
    
    # Change to the dataset directory
    cd "$dataset/"
    
    # Set up environment variables for current dataset
    TRAIN_DATA="/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section0_${dataset}/train/"
    VAL_DATA="/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section0_${dataset}/test/"
    MODEL_PATH="/scratch365/jshi1/MacroSimGNN/Protein_TL/model_min_loss_glycan"
    SAVE_PATH="/scratch365/jshi1/MacroSimGNN/Protein_TL/${dataset}/modelhistogram"
    
    # Create save directory if it doesn't exist
    mkdir -p "$(dirname "$SAVE_PATH")"
    
    # Run the training script
    python /scratch365/jshi1/MacroSimGNN/Model/src/main.py \
        --epochs 1000 \
        --batch-size 256 \
        --histogram \
        --restart \
        --load-path "$MODEL_PATH" \
        --save-path "$SAVE_PATH" \
        --training-graphs "$TRAIN_DATA" \
        --testing-graphs "$VAL_DATA"
    
    echo "Job completed for $dataset"
    
    # Return to parent directory
    cd ../
done

echo "All jobs completed successfully!"
