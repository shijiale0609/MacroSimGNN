import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score, mean_absolute_error

X = np.load("targets.npy")
Y = np.load("predictions.npy")
r2 = r2_score(X, Y)
mae = mean_absolute_error(X,Y)

print("r2:", r2, "mae:", mae)