#!/bin/bash
#$ -N PT_70_42
#$ -M jshi1@nd.edu
#$ -m abe
#$ -q long
#$ -pe smp 1

source ~/.bashrc
conda activate simgnn

# Change to the job directory

# Set up environment variables
TRAIN_DATA=/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section0_70_42/train/
VAL_DATA=/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section0_70_42/test/
MODEL_PATH=/scratch365/jshi1/MacroSimGNN/Protein_TL/model_min_loss_glycan
SAVE_PATH=./modelhistogram

# Run the training script
python /scratch365/jshi1/MacroSimGNN/Model/src/main.py \
    --epochs 1000 \
    --batch-size 256 \
    --histogram \
    --restart \
    --load-path $MODEL_PATH \
    --save-path $SAVE_PATH \
    --training-graphs $TRAIN_DATA \
    --testing-graphs $VAL_DATA

echo "Job completed for 70_42"
