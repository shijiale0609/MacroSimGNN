#!/bin/bash

# List of directories to process (sorted alphabetically)

directories=(
#"10_42/" "10_53/" "10_64/" "10_75/" "10_86/"
#"20_42/" "20_53/" "20_64/" "20_75/" "20_86/"
#"30_42/" "30_53/" "30_64/" "30_75/" "30_86/"
#"40_42/" "40_53/" "40_64/" "40_75/" "40_86/"
#"50_42/" "50_53/" "50_64/" "50_75/" "50_86/"
"60_42/" "60_53/" "60_64/" "60_75/" "60_86/"
"70_42/" "70_53/" "70_64/" "70_75/" "70_86/"
"80_42/" "80_53/" "80_64/" "80_75/" "80_86/"
"90_42/" "90_53/" "90_64/" "90_75/" "90_86/"
"100_42/" "100_53/" "100_64/" "100_75/" "100_86/"
)


# Loop through each directory
for dir in "${directories[@]}"; do
    # Remove trailing slash for cleaner job names
    clean_dir=${dir%/}
    
    # Create the directory if it doesn't exist
    mkdir -p $dir
    
    cd $dir
    # Create the qsub script for this parameter combination
    cat > "job_${clean_dir}.sh" << EOF
#!/bin/bash
#$ -N Pro_${clean_dir}
#$ -M jshi1@nd.edu
#$ -m abe
#$ -q long
#$ -pe smp 1

source ~/.bashrc
conda activate simgnn

# Change to the job directory

# Set up environment variables
TRAIN_DATA=/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section0_${clean_dir}/train/
VAL_DATA=/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section0_${clean_dir}/test/
SAVE_PATH=./modelhistogram

# Run the training script
python /scratch365/jshi1/MacroSimGNN/Model/src/main.py \\
    --epochs 1000 \\
    --batch-size 256 \\
    --histogram \\
    --save-path \$SAVE_PATH \\
    --training-graphs \$TRAIN_DATA \\
    --testing-graphs \$VAL_DATA

echo "Job completed for ${clean_dir}"
EOF

    # Submit the job to the queue
    echo "Submitting job for ${clean_dir}..."
    qsub "job_${clean_dir}.sh"
    cd ../
done

