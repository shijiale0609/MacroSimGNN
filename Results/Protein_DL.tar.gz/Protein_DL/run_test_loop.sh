#!/bin/bash

# List of directories to process (sorted alphabetically)

directories=(
#"10_42/" "10_53/" "10_64/" "10_75/" "10_86/"
#"20_42/" "20_53/" "20_64/" "20_75/" "20_86/"
#"30_42/" "30_53/" "30_64/" "30_75/" "30_86/"
#"40_42/" "40_53/" "40_64/" "40_75/" "40_86/"
#"50_42/" "50_53/" "50_64/" "50_75/" "50_86/"
#"60_42/" "60_53/" "60_64/" "60_75/" "60_86/"
#"70_42/" "70_53/" "70_64/" "70_75/" "70_86/"
#"80_42/" "80_53/" "80_64/" "80_75/" "80_86/"
#"90_42/" "90_53/" "90_64/" "90_75/" "90_86/"
"100_42/" #"100_53/" "100_64/" "100_75/" "100_86/"
)


# Loop through each directory
for dir in "${directories[@]}"; do
    # Remove trailing slash for cleaner job names
    clean_dir=${dir%/}
    
    cd $dir
    # Create the qsub script for this parameter combination

    mkdir test1
    cd test1/
    # Set up environment variables
    TEST_DATA=/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section1/test/
    MODEL_PATH=./../model_min_loss

    # Run the test script
    python /scratch365/jshi1/MacroSimGNN/Model/src/main.py --batch-size 256 --histogram --load-path "$MODEL_PATH" --testing-graphs "$TEST_DATA"

    cd ../

    mkdir test2
    cd test2/
    # Set up environment variables
    TEST_DATA=/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section2/test/
    MODEL_PATH=./../model_min_loss

    # Run the test script
    python /scratch365/jshi1/MacroSimGNN/Model/src/main.py --batch-size 256 --histogram --load-path "$MODEL_PATH" --testing-graphs "$TEST_DATA"

    cd ../

    mkdir test3
    cd test3/
    # Set up environment variables
    TEST_DATA=/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section3/test/
    MODEL_PATH=./../model_min_loss

    # Run the test script
    python /scratch365/jshi1/MacroSimGNN/Model/src/main.py --batch-size 256 --histogram --load-path "$MODEL_PATH" --testing-graphs "$TEST_DATA"

    cd ../

    # Submit the job to the queue
    echo "Complete test postprocess job for ${clean_dir}..."
    cd ../
done

