#!/bin/bash
#$ -N Pro_20_53
#$ -M jshi1@nd.edu
#$ -m abe
#$ -q long
#$ -pe smp 2

conda activate simgnn

# Change to the job directory

# Set up environment variables
TRAIN_DATA=/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section0_20_53/train/
VAL_DATA=/scratch365/jshi1/MacroSimGNN/Protein_dataset/protein_test_data_set_section0_20_53/test/
SAVE_PATH=./modelhistogram

# Run the training script
python /scratch365/jshi1/MacroSimGNN/Model/src/main.py \
    --epochs 1000 \
    --batch-size 256 \
    --histogram \
    --save-path $SAVE_PATH \
    --training-graphs $TRAIN_DATA \
    --testing-graphs $VAL_DATA

echo "Job completed for 20_53"
